from setuptools import setup

setup(
    name='Sigmath',
    version='1.0.0',
    author='Enginestein',
    author_email='enginestein@gmail.com',
    description='A framework for mathematicians',
    packages=[''],
    package_data={'': ['C:\\Main\\Projects\\C#\\Sigmath\\bin\\Debug\\Sigmath.dll']}
)